﻿namespace ElectricityReadings.DAL.DataSource
{


    partial class DAL_DS_ElectricityReadings
    {
        partial class tbl_viewDataTable
        {
        }

        partial class tbl_CountDataTable
        {
        }

        partial class tbl_DoubleClickDataTable
        {

        }

        partial class tbl_readingsDataTable
        {
        }
    }
}
