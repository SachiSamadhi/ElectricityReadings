﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OracleClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ElectricityReadings.DAL
{
    class DAL_CS_ElectricityReadings
    {

        //LOAD MAIN ELECTRICITY READINGS (V1)
        public DataTable LoadReadings()
        {
            DBconnect.connect();

            DAL.DataSource.DAL_DS_ElectricityReadings ds = new DataSource.DAL_DS_ElectricityReadings();
            DataTable dt = ds.tbl_readings;

            string query = @"SELECT cer_date,
                                    cer_time,
                                    cer_meter_no,
                                  (SELECT cem_location AS location
                                    FROM cdl_electricity_meters
                                    WHERE cem_meter_no = cer_meter_no)AS location,
                                    cer_maximum_demand,
                                    cer_current_reading
                            FROM   cdl_electricity_readings
                            ORDER  BY cer_meter_no,
                                To_char(cer_date, 'RRRR-MM') ";

            OracleDataReader odr = DBconnect.readtable(query, null);
            while (odr.Read())
            {
                DataRow r = dt.NewRow();

                r["cer_date"] = odr["cer_date"].ToString();
                r["cer_time"] = odr["cer_time"].ToString();
                r["cer_meter_no"] = odr["cer_meter_no"].ToString();
                r["location"] = odr["location"].ToString();
                r["cer_maximum_demand"] = odr["cer_maximum_demand"].ToString();
                r["cer_current_reading"] = odr["cer_current_reading"].ToString();
                dt.Rows.Add(r);

            }
            odr.Close();
            return dt;
        }

        //LOAD USER METERS
        public DataTable GetUserMeters()
        {
            DBconnect.connect();
            DAL.DataSource.DAL_DS_ElectricityReadings ds = new DataSource.DAL_DS_ElectricityReadings();
            DataTable dt = ds.tbl_DoubleClick;


            string query = @"SELECT Substr(cem_location, 1, 50) AS cem_location,cem_meter_no  
                             FROM   cdl_electricity_meters     
                             WHERE  cem_meter_no IN(SELECT ceu_meter_no
                                                         FROM   cdl_elemeter_users
                                                         WHERE  ceu_meter_no = cem_meter_no
                                                         AND ceu_service_no = USER
                                                         AND ceu_status = 'A')";

            OracleDataReader dr = DBconnect.readtable(query, null);

            while (dr.Read())
            {
                DataRow r = dt.NewRow();

                r["cem_location"] = dr["cem_location"].ToString();
                r["cem_meter_no"] = dr["cem_meter_no"].ToString();
                dt.Rows.Add(r);
            }


            dr.Close();
            return dt;
        }

        //LOAD READING VIEW (V2)      
        public DataTable GetElecReadingView(string meterNo, string cerDate)
        {
            DBconnect.connect();
            DAL.DataSource.DAL_DS_ElectricityReadings ds = new DataSource.DAL_DS_ElectricityReadings();
            DataTable dt = ds.tbl_view;

            string query = @"
                SELECT cev_set_no,
                       to_char(cev_date, 'RRRR-MM-DD') AS cev_date,
                       cev_time,
                       cev_meter_no,
                       cev_curr_reading,
                       cev_pre_reading,
                       cev_maximum_demand,
                       cev_cur_comsumption
                FROM cdl_elecreading_view
                WHERE cev_meter_no = '" + meterNo + @"'
                AND TO_CHAR(cev_date,'YYYY-MM-DD') = '" + cerDate + @"'
                ORDER BY cev_date";

            OracleDataReader odr = DBconnect.readtable(query, null);

            while (odr.Read())
            {
                DataRow r = dt.NewRow();
                r["cev_set_no"] = odr["cev_set_no"].ToString();
                r["cev_date"] = odr["cev_date"].ToString();
                r["cev_time"] = odr["cev_time"].ToString();
                r["cev_meter_no"] = odr["cev_meter_no"].ToString();
                r["cev_pre_reading"] = odr["cev_pre_reading"].ToString();
                r["cev_maximum_demand"] = odr["cev_maximum_demand"].ToString();
                r["cev_curr_reading"] = odr["cev_curr_reading"].ToString();
                r["cev_cur_comsumption"] = odr["cev_cur_comsumption"].ToString();
                dt.Rows.Add(r);
            }
            odr.Close();
            return dt;
        }

        //  CHECK DUPLICATE (mem_count)   
        internal int CheckDuplicate(string meterNo, string cerDate)
        {
            DBconnect.connect();
            int count = 0;

            string query = @"SELECT COUNT(*) AS mem_count
                     FROM cdl_electricity_readings
                     WHERE cer_meter_no = '" + meterNo + @"'
                     AND TO_CHAR(cer_date,'YYYY-MM-DD') = '" + cerDate + @"'";

            OracleDataReader odr = DBconnect.readtable(query, null);

            if (odr.Read())
            {
                count = Convert.ToInt32(odr["mem_count"]);
            }

            odr.Close();

            return count;
        }

        //CHECK DATE(MAX_DATE)
        public DataTable CheckDate()
        {
            DBconnect.connect();
            DAL.DataSource.DAL_DS_ElectricityReadings ds = new DataSource.DAL_DS_ElectricityReadings();
            DataTable dt = ds.tbl_readings;

            string query = @"SELECT Max(cer_date) AS mem_date
                             FROM   cdl_electricity_readings
                             WHERE  cer_meter_no = cer_meter_no";

            OracleDataReader odr = DBconnect.readtable(query, null);
            while (odr.Read())
            {
                DataRow r = dt.NewRow();
                r["cer_time"] = odr["mem_date"].ToString();
                dt.Rows.Add(r);
            }
            odr.Close();

            return dt;
        }

        // SAVE-Insert,Update
        internal bool SaveElectricityReading(string cerDate, string cerTime, string meterNo, string cerMaximumDemand, string cerCurrentReading, string update)
        {
            bool result = false;

            DBconnect.connect();

            decimal maxDemand = 0;
            decimal currentReading = 0;

            decimal.TryParse(cerMaximumDemand, out maxDemand);
            decimal.TryParse(cerCurrentReading, out currentReading);


            //if(update == "1")
            //{
            string update_query = @"UPDATE cdl_electricity_readings
                        SET cer_maximum_demand = " + maxDemand + @",
                            cer_current_reading = " + currentReading + @",
                            cer_time = TO_DATE('" + cerTime + @"','HH24:MI:SS'),
                            updated_by = '" + Connection.UserName + @"',
                            updated_date = SYSDATE
                        WHERE cer_meter_no = '" + meterNo + @"'
                          AND TRUNC(cer_date) = TO_DATE('" + cerDate + @"','YYYY-MM-DD')";
            bool updated = DBconnect.AddEditDel(update_query);


            if (!updated)
            {
                string insert_query = @"INSERT INTO cdl_electricity_readings (
                                    cer_date,
                                    cer_time,
                                    cer_meter_no,
                                    cer_maximum_demand,
                                    cer_current_reading,
                                    created_by,
                                    created_date
                                )
                                VALUES (
                                    TO_DATE('" + cerDate + @"', 'YYYY-MM-DD'),
                                    TO_DATE('" + cerTime + @"','HH24:MI:SS'),
                                    '" + meterNo + @"',
                                    " + maxDemand + @",
                                    " + currentReading + @",
                                    '" + Connection.UserName + @"',
                                    SYSDATE)";

                result = DBconnect.AddEditDel(insert_query);
            }
            else
            {
                result = true;
            }
            //}
            //string update_query = @"UPDATE cdl_electricity_readings
            //                SET cer_maximum_demand = " + maxDemand + @",
            //                    cer_current_reading = " + currentReading + @",
            //                    updated_by = '" + Connection.UserName + @"',
            //                    updated_date = SYSDATE
            //                WHERE cer_meter_no = '" + meterNo + @"'
            //                  AND TRUNC(cer_date) = TO_DATE('" + cerDate + @"','YYYY-MM-DD')";
            //                //AND TO_CHAR(cer_time,'HH24:MI:SS') = '" + cerTime + @"'";

            //bool updated = DBconnect.AddEditDel(update_query);


            //if (!updated)
            //{
            //    string insert_query = @"INSERT INTO cdl_electricity_readings (
            //                        cer_date,
            //                        cer_time,
            //                        cer_meter_no,
            //                        cer_maximum_demand,
            //                        cer_current_reading,
            //                        created_by,
            //                        created_date
            //                    )
            //                    VALUES (
            //                        TO_DATE('" + cerDate + @"', 'YYYY-MM-DD'),
            //                        TO_DATE('" + cerTime + @"','HH24:MI:SS'),
            //                        '" + meterNo + @"',
            //                        " + maxDemand + @",
            //                        " + currentReading + @",
            //                        '" + Connection.UserName + @"',
            //                        SYSDATE)";

            //    result = DBconnect.AddEditDel(insert_query);
            //}
            //else
            //{
            //    result = true;
            //}

            return result;

        }

        //check date
        public DateTime? GetMaxReadingDate(string meterNo)
        {
            DBconnect.connect();

            string query = @"SELECT MAX(cer_date)
                     FROM cdl_electricity_readings
                     WHERE cer_meter_no = '" + meterNo + @"'";

            OracleDataReader odr = DBconnect.readtable(query, null);

            DateTime? maxDate = null;
            if (odr.Read() && odr[0] != DBNull.Value)
                maxDate = Convert.ToDateTime(odr[0]);

            odr.Close();
            return maxDate;
        }

        //Get Saved Time
        public DataTable GetSavedTime(string meterNo, string cerDate)
        {
            DBconnect.connect();

            DAL.DataSource.DAL_DS_ElectricityReadings ds = new DataSource.DAL_DS_ElectricityReadings();

            DataTable dt = ds.tbl_readings;

            string query = @"SELECT cer_time
                     FROM cdl_electricity_readings
                     WHERE cer_meter_no = '" + meterNo + @"'
                     AND TRUNC(cer_date) = TO_DATE('" + cerDate + @"', 'YYYY-MM-DD')";

            OracleDataReader odr = DBconnect.readtable(query, null);

            while (odr.Read())
            {
                DataRow r = dt.NewRow();
                r["cer_time"] = odr["cer_time"].ToString();
                dt.Rows.Add(r);

                break;
            }

            odr.Close();
            return dt;
        }

        //Reading Record By Date
        public DataTable LoadReadingsByDate(string cerDate)
        {
            DBconnect.connect();
            DAL.DataSource.DAL_DS_ElectricityReadings ds = new DAL.DataSource.DAL_DS_ElectricityReadings();
            DataTable dt = ds.tbl_view;

            string query = @"SELECT cev_set_no,
                           TO_CHAR(cev_date, 'YYYY-MM-DD') AS cev_date,
                           cev_time,
                           cev_meter_no,
                           cev_curr_reading,
                           cev_pre_reading,
                           cev_maximum_demand,
                           cev_cur_comsumption
                       FROM cdl_elecreading_view
                       WHERE TRUNC(cev_date) = TO_DATE('" + cerDate + @"', 'YYYY-MM-DD')
                       ORDER BY cev_time";

            OracleDataReader odr = DBconnect.readtable(query, null);
            while (odr.Read())
            {
                DataRow r = dt.NewRow();

                r["cev_set_no"] = odr["cev_set_no"].ToString();
                r["cev_date"] = odr["cev_date"].ToString();
                r["cev_time"] = odr["cev_time"] == DBNull.Value ? "" : odr["cev_time"].ToString();
                r["cev_meter_no"] = odr["cev_meter_no"].ToString();
                r["cev_pre_reading"] = odr["cev_pre_reading"].ToString();
                r["cev_maximum_demand"] = odr["cev_maximum_demand"].ToString();
                r["cev_curr_reading"] = odr["cev_curr_reading"].ToString();
                r["cev_cur_comsumption"] = odr["cev_cur_comsumption"].ToString();

                dt.Rows.Add(r);
            }

            odr.Close();


            return dt;

        }

    }
}
