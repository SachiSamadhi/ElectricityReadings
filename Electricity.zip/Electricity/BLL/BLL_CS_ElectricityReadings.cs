﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ElectricityReadings.BLL
{
    class BLL_CS_ElectricityReadings
    {
        DAL.DAL_CS_ElectricityReadings dal = new DAL.DAL_CS_ElectricityReadings();

        //LOAD V1 – MAIN READINGS
        public DataTable LoadReadings()
        {
            return dal.LoadReadings();
        }

        //LOAD USER METERS
        public DataTable GetMeters()
        {
            return dal.GetUserMeters();
        }


        // LOAD V2 – DAILY VIEW
        public DataTable LoadDailyView(string meterNo, string cerDate)
        {

            return dal.GetElecReadingView(meterNo, cerDate);
        }

      
        //BEFORE INSERT VALIDATION (E1)
        internal bool IsInvalidNextDate(string meterNo, DateTime selectedDate, out DateTime expectedDate)
        {
            expectedDate = DateTime.MinValue;

            DateTime? maxDate = dal.GetMaxReadingDate(meterNo);

            
            if (maxDate == null)
                return false;

            expectedDate = maxDate.Value.AddDays(1);

            return selectedDate.Date != expectedDate.Date;
        }

        //SAVE BUTTON LOGIC
        internal bool SaveElectricityReading(string cerDate, string cerTime, string meterNo, string cerMaximumDemand, string cerCurrentReading, string update)
        {
            return dal.SaveElectricityReading(cerDate, cerTime, meterNo,cerMaximumDemand, cerCurrentReading, update);
        }


        //CHECK DUPLICATE
        internal int CheckDuplicate(string meterNo, string cerDate)
        {
            //int count = dal.CheckDuplicate(meterNo, cerDate);
            //return count > 0;
            return dal.CheckDuplicate(meterNo, cerDate);
        }

        //CHECK DATE(MAX_DATE)
        public DataTable CheckDate()
        {
            return dal.CheckDate();
        }

        //Get Saved Time
        public DataTable GetSavedTime(string meterNo, string cerDate)
        {
            return dal.GetSavedTime(meterNo, cerDate);
        }

        //Reading Record by Date
        public DataTable GetElecReadingbyDate(string cerDate)
        {
            return dal.LoadReadingsByDate(cerDate);
        }

    }
}
