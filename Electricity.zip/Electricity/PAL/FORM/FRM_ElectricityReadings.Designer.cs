﻿namespace ElectricityReadings
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.tblreadingsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dAL_DS_ElectricityReadings = new ElectricityReadings.DAL.DataSource.DAL_DS_ElectricityReadings();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.lblDate = new DevExpress.XtraEditors.LabelControl();
            this.lblTime = new DevExpress.XtraEditors.LabelControl();
            this.txtTime = new DevExpress.XtraEditors.TextEdit();
            this.txtLocation = new DevExpress.XtraEditors.TextEdit();
            this.lblMeterNo = new DevExpress.XtraEditors.LabelControl();
            this.txtMeterNo = new DevExpress.XtraEditors.TextEdit();
            this.lblKWH = new DevExpress.XtraEditors.LabelControl();
            this.txtCurrent = new DevExpress.XtraEditors.TextEdit();
            this.lblCurrentRead = new DevExpress.XtraEditors.LabelControl();
            this.lblKVA = new DevExpress.XtraEditors.LabelControl();
            this.txtMaximum = new DevExpress.XtraEditors.TextEdit();
            this.lblMaximum = new DevExpress.XtraEditors.LabelControl();
            this.gcView = new DevExpress.XtraGrid.GridControl();
            this.gvView = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colcev_date = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colcev_time = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colcev_curr_reading = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colcev_pre_reading = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colcev_cur_comsumption = new DevExpress.XtraGrid.Columns.GridColumn();
            this.cev_meter_no = new DevExpress.XtraGrid.Columns.GridColumn();
            this.cev_maximum_demand = new DevExpress.XtraGrid.Columns.GridColumn();
            this.tblviewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panelControl3 = new DevExpress.XtraEditors.PanelControl();
            this.txttest = new DevExpress.XtraEditors.TextEdit();
            this.btn_Load = new DevExpress.XtraEditors.SimpleButton();
            this.textEdit1 = new DevExpress.XtraEditors.TextEdit();
            this.tdate1 = new DevExpress.XtraEditors.DateEdit();
            this.btn_new = new DevExpress.XtraEditors.SimpleButton();
            this.btn_Save = new DevExpress.XtraEditors.SimpleButton();
            this.pnlData = new DevExpress.XtraEditors.PanelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.gcMouseDouble = new DevExpress.XtraGrid.GridControl();
            this.tblDoubleClickBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gvMouseDouble = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colcem_location = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colcem_meter_no = new DevExpress.XtraGrid.Columns.GridColumn();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            ((System.ComponentModel.ISupportInitialize)(this.tblreadingsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dAL_DS_ElectricityReadings)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTime.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLocation.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMeterNo.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCurrent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaximum.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblviewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).BeginInit();
            this.panelControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txttest.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tdate1.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tdate1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlData)).BeginInit();
            this.pnlData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcMouseDouble)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblDoubleClickBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvMouseDouble)).BeginInit();
            this.SuspendLayout();
            // 
            // tblreadingsBindingSource
            // 
            this.tblreadingsBindingSource.DataMember = "tbl_readings";
            this.tblreadingsBindingSource.DataSource = this.dAL_DS_ElectricityReadings;
            // 
            // dAL_DS_ElectricityReadings
            // 
            this.dAL_DS_ElectricityReadings.DataSetName = "DAL_DS_ElectricityReadings";
            this.dAL_DS_ElectricityReadings.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // lblDate
            // 
            this.lblDate.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Appearance.Options.UseFont = true;
            this.lblDate.Location = new System.Drawing.Point(5, 15);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(44, 21);
            this.lblDate.TabIndex = 3;
            this.lblDate.Text = "Date -";
            // 
            // lblTime
            // 
            this.lblTime.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.Appearance.Options.UseFont = true;
            this.lblTime.Location = new System.Drawing.Point(239, 21);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(46, 21);
            this.lblTime.TabIndex = 12;
            this.lblTime.Text = "Time -";
            // 
            // txtTime
            // 
            this.txtTime.Location = new System.Drawing.Point(291, 14);
            this.txtTime.Name = "txtTime";
            this.txtTime.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTime.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtTime.Properties.Appearance.Options.UseFont = true;
            this.txtTime.Properties.Appearance.Options.UseForeColor = true;
            this.txtTime.Properties.Appearance.Options.UseTextOptions = true;
            this.txtTime.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txtTime.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.txtTime.Properties.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.txtTime.Properties.AppearanceFocused.Options.UseTextOptions = true;
            this.txtTime.Properties.AppearanceFocused.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txtTime.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtTime.Properties.AppearanceReadOnly.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTime.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtTime.Properties.AppearanceReadOnly.Options.UseFont = true;
            this.txtTime.Properties.AppearanceReadOnly.Options.UseTextOptions = true;
            this.txtTime.Properties.AppearanceReadOnly.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txtTime.Properties.AppearanceReadOnly.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.txtTime.Properties.AppearanceReadOnly.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.txtTime.Properties.BeepOnError = false;
            this.txtTime.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.SimpleMaskManager));
            this.txtTime.Properties.MaskSettings.Set("MaskManagerSignature", "ignoreMaskBlank=True");
            this.txtTime.Properties.MaskSettings.Set("mask", "90:00");
            this.txtTime.Size = new System.Drawing.Size(91, 28);
            this.txtTime.TabIndex = 14;
            this.txtTime.EditValueChanged += new System.EventHandler(this.txtTime_EditValueChanged);
            // 
            // txtLocation
            // 
            this.txtLocation.EditValue = "";
            this.txtLocation.Location = new System.Drawing.Point(559, 13);
            this.txtLocation.Name = "txtLocation";
            this.txtLocation.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtLocation.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLocation.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtLocation.Properties.Appearance.Options.UseBackColor = true;
            this.txtLocation.Properties.Appearance.Options.UseFont = true;
            this.txtLocation.Properties.Appearance.Options.UseForeColor = true;
            this.txtLocation.Properties.Appearance.Options.UseTextOptions = true;
            this.txtLocation.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txtLocation.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.txtLocation.Properties.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.txtLocation.Properties.AppearanceFocused.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLocation.Properties.AppearanceFocused.Options.UseFont = true;
            this.txtLocation.Properties.AppearanceFocused.Options.UseTextOptions = true;
            this.txtLocation.Properties.AppearanceFocused.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txtLocation.Properties.AppearanceFocused.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.txtLocation.Properties.AppearanceFocused.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.txtLocation.Properties.AppearanceReadOnly.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLocation.Properties.AppearanceReadOnly.Options.UseFont = true;
            this.txtLocation.Properties.AppearanceReadOnly.Options.UseTextOptions = true;
            this.txtLocation.Properties.AppearanceReadOnly.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txtLocation.Properties.AppearanceReadOnly.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.txtLocation.Properties.AppearanceReadOnly.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.txtLocation.Properties.ReadOnly = true;
            this.txtLocation.Size = new System.Drawing.Size(234, 28);
            this.txtLocation.TabIndex = 3;
            this.txtLocation.EditValueChanged += new System.EventHandler(this.txtLocation_EditValueChanged);
            // 
            // lblMeterNo
            // 
            this.lblMeterNo.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMeterNo.Appearance.Options.UseFont = true;
            this.lblMeterNo.Location = new System.Drawing.Point(430, 17);
            this.lblMeterNo.Name = "lblMeterNo";
            this.lblMeterNo.Size = new System.Drawing.Size(81, 21);
            this.lblMeterNo.TabIndex = 15;
            this.lblMeterNo.Text = "Meter No -";
            // 
            // txtMeterNo
            // 
            this.txtMeterNo.Location = new System.Drawing.Point(507, 14);
            this.txtMeterNo.Name = "txtMeterNo";
            this.txtMeterNo.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtMeterNo.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMeterNo.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtMeterNo.Properties.Appearance.Options.UseBackColor = true;
            this.txtMeterNo.Properties.Appearance.Options.UseFont = true;
            this.txtMeterNo.Properties.Appearance.Options.UseForeColor = true;
            this.txtMeterNo.Properties.Appearance.Options.UseTextOptions = true;
            this.txtMeterNo.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txtMeterNo.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.txtMeterNo.Properties.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.txtMeterNo.Properties.AppearanceDisabled.Options.UseTextOptions = true;
            this.txtMeterNo.Properties.AppearanceDisabled.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txtMeterNo.Properties.AppearanceFocused.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMeterNo.Properties.AppearanceFocused.Options.UseFont = true;
            this.txtMeterNo.Properties.AppearanceFocused.Options.UseTextOptions = true;
            this.txtMeterNo.Properties.AppearanceFocused.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txtMeterNo.Properties.AppearanceFocused.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.txtMeterNo.Properties.AppearanceFocused.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.txtMeterNo.Properties.AppearanceReadOnly.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMeterNo.Properties.AppearanceReadOnly.Options.UseFont = true;
            this.txtMeterNo.Properties.AppearanceReadOnly.Options.UseTextOptions = true;
            this.txtMeterNo.Properties.AppearanceReadOnly.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txtMeterNo.Properties.AppearanceReadOnly.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.txtMeterNo.Properties.AppearanceReadOnly.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.txtMeterNo.Properties.ReadOnly = true;
            this.txtMeterNo.Size = new System.Drawing.Size(49, 28);
            this.txtMeterNo.TabIndex = 16;
            this.txtMeterNo.EditValueChanged += new System.EventHandler(this.txtMeterNo_EditValueChanged_1);
            this.txtMeterNo.DoubleClick += new System.EventHandler(this.txtMeterNo_DoubleClick);
            this.txtMeterNo.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtMeterNo_MouseDoubleClick);
            // 
            // lblKWH
            // 
            this.lblKWH.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKWH.Appearance.Options.UseFont = true;
            this.lblKWH.Location = new System.Drawing.Point(708, 60);
            this.lblKWH.Name = "lblKWH";
            this.lblKWH.Size = new System.Drawing.Size(34, 21);
            this.lblKWH.TabIndex = 21;
            this.lblKWH.Text = "KWh";
            // 
            // txtCurrent
            // 
            this.txtCurrent.Location = new System.Drawing.Point(582, 53);
            this.txtCurrent.Name = "txtCurrent";
            this.txtCurrent.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCurrent.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtCurrent.Properties.Appearance.Options.UseFont = true;
            this.txtCurrent.Properties.Appearance.Options.UseForeColor = true;
            this.txtCurrent.Properties.Appearance.Options.UseTextOptions = true;
            this.txtCurrent.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txtCurrent.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.txtCurrent.Properties.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.txtCurrent.Properties.AppearanceFocused.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCurrent.Properties.AppearanceFocused.Options.UseFont = true;
            this.txtCurrent.Properties.AppearanceFocused.Options.UseTextOptions = true;
            this.txtCurrent.Properties.AppearanceFocused.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txtCurrent.Properties.AppearanceFocused.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.txtCurrent.Properties.AppearanceFocused.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.txtCurrent.Properties.AppearanceReadOnly.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCurrent.Properties.AppearanceReadOnly.Options.UseFont = true;
            this.txtCurrent.Properties.AppearanceReadOnly.Options.UseTextOptions = true;
            this.txtCurrent.Properties.AppearanceReadOnly.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txtCurrent.Properties.AppearanceReadOnly.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.txtCurrent.Properties.AppearanceReadOnly.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.txtCurrent.Properties.BeepOnError = false;
            this.txtCurrent.Properties.DisplayFormat.FormatString = "#,##0.00";
            this.txtCurrent.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtCurrent.Properties.EditFormat.FormatString = "n0";
            this.txtCurrent.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.txtCurrent.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.txtCurrent.Properties.MaskSettings.Set("MaskManagerSignature", "allowNull=False");
            this.txtCurrent.Properties.MaskSettings.Set("mask", "d");
            this.txtCurrent.Properties.UseMaskAsDisplayFormat = true;
            this.txtCurrent.Size = new System.Drawing.Size(124, 28);
            this.txtCurrent.TabIndex = 20;
            this.txtCurrent.EditValueChanged += new System.EventHandler(this.txtCurrent_EditValueChanged);
            // 
            // lblCurrentRead
            // 
            this.lblCurrentRead.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentRead.Appearance.Options.UseFont = true;
            this.lblCurrentRead.Location = new System.Drawing.Point(447, 60);
            this.lblCurrentRead.Name = "lblCurrentRead";
            this.lblCurrentRead.Size = new System.Drawing.Size(129, 21);
            this.lblCurrentRead.TabIndex = 19;
            this.lblCurrentRead.Text = "Current Reading -";
            // 
            // lblKVA
            // 
            this.lblKVA.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKVA.Appearance.Options.UseFont = true;
            this.lblKVA.Location = new System.Drawing.Point(295, 60);
            this.lblKVA.Name = "lblKVA";
            this.lblKVA.Size = new System.Drawing.Size(31, 21);
            this.lblKVA.TabIndex = 18;
            this.lblKVA.Text = "KVA";
            this.lblKVA.Click += new System.EventHandler(this.lblKVA_Click_1);
            // 
            // txtMaximum
            // 
            this.txtMaximum.Location = new System.Drawing.Point(166, 53);
            this.txtMaximum.Name = "txtMaximum";
            this.txtMaximum.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaximum.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txtMaximum.Properties.Appearance.Options.UseFont = true;
            this.txtMaximum.Properties.Appearance.Options.UseForeColor = true;
            this.txtMaximum.Properties.Appearance.Options.UseTextOptions = true;
            this.txtMaximum.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txtMaximum.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.txtMaximum.Properties.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.txtMaximum.Properties.AppearanceFocused.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaximum.Properties.AppearanceFocused.Options.UseFont = true;
            this.txtMaximum.Properties.AppearanceFocused.Options.UseTextOptions = true;
            this.txtMaximum.Properties.AppearanceFocused.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txtMaximum.Properties.AppearanceFocused.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.txtMaximum.Properties.AppearanceFocused.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.txtMaximum.Properties.AppearanceReadOnly.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaximum.Properties.AppearanceReadOnly.Options.UseFont = true;
            this.txtMaximum.Properties.AppearanceReadOnly.Options.UseTextOptions = true;
            this.txtMaximum.Properties.AppearanceReadOnly.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txtMaximum.Properties.AppearanceReadOnly.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.txtMaximum.Properties.AppearanceReadOnly.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.txtMaximum.Properties.BeepOnError = false;
            this.txtMaximum.Properties.DisplayFormat.FormatString = "\"n,\"";
            this.txtMaximum.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.txtMaximum.Properties.EditFormat.FormatString = "no";
            this.txtMaximum.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.txtMaximum.Properties.MaskSettings.Set("mask", "d");
            this.txtMaximum.Properties.UseMaskAsDisplayFormat = true;
            this.txtMaximum.Size = new System.Drawing.Size(123, 28);
            this.txtMaximum.TabIndex = 18;
            this.txtMaximum.EditValueChanged += new System.EventHandler(this.txtMaximum_EditValueChanged);
            this.txtMaximum.TextChanged += new System.EventHandler(this.txtMaximum_TextChanged);
            this.txtMaximum.Leave += new System.EventHandler(this.txtMaximum_Leave);
            // 
            // lblMaximum
            // 
            this.lblMaximum.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaximum.Appearance.Options.UseFont = true;
            this.lblMaximum.Location = new System.Drawing.Point(5, 60);
            this.lblMaximum.Name = "lblMaximum";
            this.lblMaximum.Size = new System.Drawing.Size(147, 21);
            this.lblMaximum.TabIndex = 18;
            this.lblMaximum.Text = "Maximum Demand -";
            // 
            // gcView
            // 
            this.gcView.AccessibleName = "Daily Readings";
            this.gcView.DataMember = "tbl_view";
            this.gcView.DataSource = this.dAL_DS_ElectricityReadings;
            this.gcView.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.gcView.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gcView.Location = new System.Drawing.Point(12, 130);
            this.gcView.MainView = this.gvView;
            this.gcView.Name = "gcView";
            this.gcView.Size = new System.Drawing.Size(1142, 625);
            this.gcView.TabIndex = 4;
            this.gcView.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvView});
            // 
            // gvView
            // 
            this.gvView.Appearance.ColumnFilterButton.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.gvView.Appearance.ColumnFilterButton.Options.UseFont = true;
            this.gvView.AppearancePrint.EvenRow.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.gvView.AppearancePrint.EvenRow.Options.UseFont = true;
            this.gvView.AppearancePrint.HeaderPanel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.gvView.AppearancePrint.HeaderPanel.Options.UseFont = true;
            this.gvView.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gvView.AppearancePrint.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.gvView.ColumnPanelRowHeight = 46;
            this.gvView.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colcev_date,
            this.colcev_time,
            this.colcev_curr_reading,
            this.colcev_pre_reading,
            this.colcev_cur_comsumption,
            this.cev_meter_no,
            this.cev_maximum_demand});
            this.gvView.GridControl = this.gcView;
            this.gvView.GroupRowHeight = 30;
            this.gvView.Name = "gvView";
            this.gvView.OptionsBehavior.Editable = false;
            this.gvView.OptionsBehavior.ReadOnly = true;
            this.gvView.OptionsDetail.EnableMasterViewMode = false;
            this.gvView.OptionsFind.AlwaysVisible = true;
            this.gvView.OptionsPrint.EnableAppearanceEvenRow = true;
            this.gvView.OptionsView.ShowGroupPanel = false;
            this.gvView.OptionsView.ShowHorizontalLines = DevExpress.Utils.DefaultBoolean.True;
            this.gvView.OptionsView.ShowIndicator = false;
            this.gvView.RowHeight = 25;
            this.gvView.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.cev_meter_no, DevExpress.Data.ColumnSortOrder.Ascending)});
            this.gvView.RowCellClick += new DevExpress.XtraGrid.Views.Grid.RowCellClickEventHandler(this.gvView_RowCellClick);
            this.gvView.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gvView_FocusedRowChanged);
            // 
            // colcev_date
            // 
            this.colcev_date.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.colcev_date.AppearanceCell.Options.UseFont = true;
            this.colcev_date.AppearanceCell.Options.UseTextOptions = true;
            this.colcev_date.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colcev_date.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colcev_date.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.colcev_date.AppearanceHeader.Options.UseFont = true;
            this.colcev_date.AppearanceHeader.Options.UseTextOptions = true;
            this.colcev_date.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colcev_date.Caption = "Date";
            this.colcev_date.FieldName = "cev_date";
            this.colcev_date.MinWidth = 25;
            this.colcev_date.Name = "colcev_date";
            this.colcev_date.Visible = true;
            this.colcev_date.VisibleIndex = 0;
            this.colcev_date.Width = 152;
            // 
            // colcev_time
            // 
            this.colcev_time.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.colcev_time.AppearanceCell.Options.UseFont = true;
            this.colcev_time.AppearanceCell.Options.UseTextOptions = true;
            this.colcev_time.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colcev_time.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colcev_time.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.colcev_time.AppearanceHeader.Options.UseFont = true;
            this.colcev_time.AppearanceHeader.Options.UseTextOptions = true;
            this.colcev_time.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colcev_time.Caption = "Time";
            this.colcev_time.FieldName = "cev_time";
            this.colcev_time.MinWidth = 25;
            this.colcev_time.Name = "colcev_time";
            this.colcev_time.Visible = true;
            this.colcev_time.VisibleIndex = 1;
            this.colcev_time.Width = 139;
            // 
            // colcev_curr_reading
            // 
            this.colcev_curr_reading.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.colcev_curr_reading.AppearanceCell.Options.UseFont = true;
            this.colcev_curr_reading.AppearanceCell.Options.UseTextOptions = true;
            this.colcev_curr_reading.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colcev_curr_reading.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colcev_curr_reading.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.colcev_curr_reading.AppearanceHeader.Options.UseFont = true;
            this.colcev_curr_reading.AppearanceHeader.Options.UseTextOptions = true;
            this.colcev_curr_reading.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colcev_curr_reading.Caption = "Current Reading";
            this.colcev_curr_reading.FieldName = "cev_curr_reading";
            this.colcev_curr_reading.MinWidth = 25;
            this.colcev_curr_reading.Name = "colcev_curr_reading";
            this.colcev_curr_reading.Visible = true;
            this.colcev_curr_reading.VisibleIndex = 3;
            this.colcev_curr_reading.Width = 166;
            // 
            // colcev_pre_reading
            // 
            this.colcev_pre_reading.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.colcev_pre_reading.AppearanceCell.Options.UseFont = true;
            this.colcev_pre_reading.AppearanceCell.Options.UseTextOptions = true;
            this.colcev_pre_reading.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colcev_pre_reading.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colcev_pre_reading.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.colcev_pre_reading.AppearanceHeader.Options.UseFont = true;
            this.colcev_pre_reading.AppearanceHeader.Options.UseTextOptions = true;
            this.colcev_pre_reading.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colcev_pre_reading.Caption = "Previous Reading";
            this.colcev_pre_reading.FieldName = "cev_pre_reading";
            this.colcev_pre_reading.Name = "colcev_pre_reading";
            this.colcev_pre_reading.Visible = true;
            this.colcev_pre_reading.VisibleIndex = 4;
            this.colcev_pre_reading.Width = 180;
            // 
            // colcev_cur_comsumption
            // 
            this.colcev_cur_comsumption.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.colcev_cur_comsumption.AppearanceCell.Options.UseFont = true;
            this.colcev_cur_comsumption.AppearanceCell.Options.UseTextOptions = true;
            this.colcev_cur_comsumption.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colcev_cur_comsumption.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colcev_cur_comsumption.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.colcev_cur_comsumption.AppearanceHeader.Options.UseFont = true;
            this.colcev_cur_comsumption.AppearanceHeader.Options.UseTextOptions = true;
            this.colcev_cur_comsumption.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colcev_cur_comsumption.Caption = "Cur/Comsumption";
            this.colcev_cur_comsumption.FieldName = "cev_cur_comsumption";
            this.colcev_cur_comsumption.Name = "colcev_cur_comsumption";
            this.colcev_cur_comsumption.Visible = true;
            this.colcev_cur_comsumption.VisibleIndex = 6;
            this.colcev_cur_comsumption.Width = 183;
            // 
            // cev_meter_no
            // 
            this.cev_meter_no.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.cev_meter_no.AppearanceCell.Options.UseFont = true;
            this.cev_meter_no.AppearanceCell.Options.UseTextOptions = true;
            this.cev_meter_no.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.cev_meter_no.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.cev_meter_no.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.cev_meter_no.AppearanceHeader.Options.UseFont = true;
            this.cev_meter_no.AppearanceHeader.Options.UseTextOptions = true;
            this.cev_meter_no.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.cev_meter_no.Caption = "Meter no";
            this.cev_meter_no.FieldName = "cev_meter_no";
            this.cev_meter_no.Name = "cev_meter_no";
            this.cev_meter_no.Visible = true;
            this.cev_meter_no.VisibleIndex = 2;
            this.cev_meter_no.Width = 143;
            // 
            // cev_maximum_demand
            // 
            this.cev_maximum_demand.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 10.2F);
            this.cev_maximum_demand.AppearanceCell.Options.UseFont = true;
            this.cev_maximum_demand.AppearanceCell.Options.UseTextOptions = true;
            this.cev_maximum_demand.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.cev_maximum_demand.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.cev_maximum_demand.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold);
            this.cev_maximum_demand.AppearanceHeader.Options.UseFont = true;
            this.cev_maximum_demand.AppearanceHeader.Options.UseTextOptions = true;
            this.cev_maximum_demand.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.cev_maximum_demand.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.cev_maximum_demand.Caption = "Maximum Demand";
            this.cev_maximum_demand.FieldName = "cev_maximum_demand";
            this.cev_maximum_demand.MinWidth = 25;
            this.cev_maximum_demand.Name = "cev_maximum_demand";
            this.cev_maximum_demand.Visible = true;
            this.cev_maximum_demand.VisibleIndex = 5;
            this.cev_maximum_demand.Width = 177;
            // 
            // tblviewBindingSource
            // 
            this.tblviewBindingSource.DataMember = "tbl_view";
            this.tblviewBindingSource.DataSource = this.dAL_DS_ElectricityReadings;
            // 
            // panelControl3
            // 
            this.panelControl3.Controls.Add(this.txttest);
            this.panelControl3.Controls.Add(this.btn_Load);
            this.panelControl3.Controls.Add(this.lblKWH);
            this.panelControl3.Controls.Add(this.textEdit1);
            this.panelControl3.Controls.Add(this.txtCurrent);
            this.panelControl3.Controls.Add(this.txtMaximum);
            this.panelControl3.Controls.Add(this.lblCurrentRead);
            this.panelControl3.Controls.Add(this.lblKVA);
            this.panelControl3.Controls.Add(this.lblMaximum);
            this.panelControl3.Controls.Add(this.tdate1);
            this.panelControl3.Controls.Add(this.btn_new);
            this.panelControl3.Controls.Add(this.btn_Save);
            this.panelControl3.Controls.Add(this.lblDate);
            this.panelControl3.Controls.Add(this.lblTime);
            this.panelControl3.Controls.Add(this.txtLocation);
            this.panelControl3.Controls.Add(this.txtTime);
            this.panelControl3.Controls.Add(this.txtMeterNo);
            this.panelControl3.Controls.Add(this.lblMeterNo);
            this.panelControl3.Location = new System.Drawing.Point(12, 12);
            this.panelControl3.Name = "panelControl3";
            this.panelControl3.Size = new System.Drawing.Size(1142, 90);
            this.panelControl3.TabIndex = 5;
            this.panelControl3.Paint += new System.Windows.Forms.PaintEventHandler(this.panelControl3_Paint);
            // 
            // txttest
            // 
            this.txttest.Location = new System.Drawing.Point(993, 53);
            this.txttest.Name = "txttest";
            this.txttest.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttest.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.txttest.Properties.Appearance.Options.UseFont = true;
            this.txttest.Properties.Appearance.Options.UseForeColor = true;
            this.txttest.Properties.Appearance.Options.UseTextOptions = true;
            this.txttest.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txttest.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.txttest.Properties.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.txttest.Properties.AppearanceFocused.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttest.Properties.AppearanceFocused.Options.UseFont = true;
            this.txttest.Properties.AppearanceFocused.Options.UseTextOptions = true;
            this.txttest.Properties.AppearanceFocused.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txttest.Properties.AppearanceFocused.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.txttest.Properties.AppearanceFocused.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.txttest.Properties.AppearanceReadOnly.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttest.Properties.AppearanceReadOnly.Options.UseFont = true;
            this.txttest.Properties.AppearanceReadOnly.Options.UseTextOptions = true;
            this.txttest.Properties.AppearanceReadOnly.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txttest.Properties.AppearanceReadOnly.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.txttest.Properties.AppearanceReadOnly.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.txttest.Properties.BeepOnError = false;
            this.txttest.Properties.DisplayFormat.FormatString = "#,##0.00";
            this.txttest.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.txttest.Properties.EditFormat.FormatString = "n0";
            this.txttest.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.txttest.Properties.UseMaskAsDisplayFormat = true;
            this.txttest.Size = new System.Drawing.Size(124, 28);
            this.txttest.TabIndex = 113;
            this.txttest.Visible = false;
            // 
            // btn_Load
            // 
            this.btn_Load.AllowFocus = false;
            this.btn_Load.Appearance.BackColor = System.Drawing.Color.DodgerBlue;
            this.btn_Load.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Load.Appearance.ForeColor = System.Drawing.Color.White;
            this.btn_Load.Appearance.Options.UseBackColor = true;
            this.btn_Load.Appearance.Options.UseFont = true;
            this.btn_Load.Appearance.Options.UseForeColor = true;
            this.btn_Load.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_Load.ImageOptions.Image")));
            this.btn_Load.Location = new System.Drawing.Point(897, 9);
            this.btn_Load.LookAndFeel.SkinName = "Metropolis";
            this.btn_Load.LookAndFeel.UseDefaultLookAndFeel = false;
            this.btn_Load.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Load.Name = "btn_Load";
            this.btn_Load.Size = new System.Drawing.Size(75, 30);
            this.btn_Load.TabIndex = 112;
            this.btn_Load.Text = "Load";
            this.btn_Load.Visible = false;
            this.btn_Load.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // textEdit1
            // 
            this.textEdit1.Location = new System.Drawing.Point(954, 53);
            this.textEdit1.Name = "textEdit1";
            this.textEdit1.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textEdit1.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.textEdit1.Properties.Appearance.Options.UseFont = true;
            this.textEdit1.Properties.Appearance.Options.UseForeColor = true;
            this.textEdit1.Properties.Appearance.Options.UseTextOptions = true;
            this.textEdit1.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.textEdit1.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.textEdit1.Properties.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.textEdit1.Properties.AppearanceFocused.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textEdit1.Properties.AppearanceFocused.Options.UseFont = true;
            this.textEdit1.Properties.AppearanceFocused.Options.UseTextOptions = true;
            this.textEdit1.Properties.AppearanceFocused.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.textEdit1.Properties.AppearanceFocused.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.textEdit1.Properties.AppearanceFocused.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.textEdit1.Properties.AppearanceReadOnly.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textEdit1.Properties.AppearanceReadOnly.Options.UseFont = true;
            this.textEdit1.Properties.AppearanceReadOnly.Options.UseTextOptions = true;
            this.textEdit1.Properties.AppearanceReadOnly.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.textEdit1.Properties.AppearanceReadOnly.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.textEdit1.Properties.AppearanceReadOnly.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.textEdit1.Properties.BeepOnError = false;
            this.textEdit1.Properties.DisplayFormat.FormatString = "#,##0.00";
            this.textEdit1.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit1.Properties.EditFormat.FormatString = "n0";
            this.textEdit1.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.textEdit1.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.textEdit1.Properties.MaskSettings.Set("MaskManagerSignature", "allowNull=False");
            this.textEdit1.Properties.MaskSettings.Set("mask", "d");
            this.textEdit1.Properties.UseMaskAsDisplayFormat = true;
            this.textEdit1.Size = new System.Drawing.Size(33, 28);
            this.textEdit1.TabIndex = 20;
            this.textEdit1.Visible = false;
            this.textEdit1.EditValueChanged += new System.EventHandler(this.txtCurrent_EditValueChanged);
            // 
            // tdate1
            // 
            this.tdate1.EditValue = null;
            this.tdate1.Location = new System.Drawing.Point(55, 14);
            this.tdate1.Name = "tdate1";
            this.tdate1.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tdate1.Properties.Appearance.Options.UseFont = true;
            this.tdate1.Properties.Appearance.Options.UseTextOptions = true;
            this.tdate1.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tdate1.Properties.BeepOnError = false;
            this.tdate1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.tdate1.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.tdate1.Properties.EditFormat.FormatString = "yyyy-MM-dd";
            this.tdate1.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.tdate1.Properties.MaskSettings.Set("mask", "yyyy-MM-dd");
            this.tdate1.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.tdate1.Properties.UseMaskAsDisplayFormat = true;
            this.tdate1.Size = new System.Drawing.Size(135, 28);
            this.tdate1.TabIndex = 6;
            this.tdate1.EditValueChanged += new System.EventHandler(this.tdate1_EditValueChanged);
            this.tdate1.TextChanged += new System.EventHandler(this.tdate1_TextChanged);
            // 
            // btn_new
            // 
            this.btn_new.Appearance.BackColor = System.Drawing.Color.DodgerBlue;
            this.btn_new.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_new.Appearance.ForeColor = System.Drawing.Color.White;
            this.btn_new.Appearance.Options.UseBackColor = true;
            this.btn_new.Appearance.Options.UseFont = true;
            this.btn_new.Appearance.Options.UseForeColor = true;
            this.btn_new.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_new.ImageOptions.Image")));
            this.btn_new.Location = new System.Drawing.Point(1051, 9);
            this.btn_new.LookAndFeel.SkinName = "Metropolis";
            this.btn_new.LookAndFeel.UseDefaultLookAndFeel = false;
            this.btn_new.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_new.Name = "btn_new";
            this.btn_new.Size = new System.Drawing.Size(75, 30);
            this.btn_new.TabIndex = 111;
            this.btn_new.Text = "New";
            this.btn_new.Click += new System.EventHandler(this.btn_new_Click);
            // 
            // btn_Save
            // 
            this.btn_Save.Appearance.BackColor = System.Drawing.Color.DodgerBlue;
            this.btn_Save.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Appearance.ForeColor = System.Drawing.Color.White;
            this.btn_Save.Appearance.Options.UseBackColor = true;
            this.btn_Save.Appearance.Options.UseFont = true;
            this.btn_Save.Appearance.Options.UseForeColor = true;
            this.btn_Save.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_Save.ImageOptions.Image")));
            this.btn_Save.Location = new System.Drawing.Point(974, 9);
            this.btn_Save.LookAndFeel.SkinName = "Metropolis";
            this.btn_Save.LookAndFeel.UseDefaultLookAndFeel = false;
            this.btn_Save.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(75, 30);
            this.btn_Save.TabIndex = 111;
            this.btn_Save.Text = "Save";
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            this.btn_Save.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btn_Save_MouseClick);
            // 
            // pnlData
            // 
            this.pnlData.Controls.Add(this.labelControl3);
            this.pnlData.Controls.Add(this.labelControl2);
            this.pnlData.Controls.Add(this.gcMouseDouble);
            this.pnlData.Location = new System.Drawing.Point(303, 106);
            this.pnlData.Name = "pnlData";
            this.pnlData.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.pnlData.Size = new System.Drawing.Size(322, 336);
            this.pnlData.TabIndex = 6;
            this.pnlData.Visible = false;
            this.pnlData.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlData_Paint);
            // 
            // labelControl3
            // 
            this.labelControl3.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("labelControl3.ImageOptions.Image")));
            this.labelControl3.Location = new System.Drawing.Point(292, 5);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(24, 24);
            this.labelControl3.TabIndex = 9;
            this.labelControl3.Click += new System.EventHandler(this.labelControl3_Click);
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl2.Appearance.ForeColor = System.Drawing.Color.DodgerBlue;
            this.labelControl2.Appearance.Options.UseFont = true;
            this.labelControl2.Appearance.Options.UseForeColor = true;
            this.labelControl2.Location = new System.Drawing.Point(5, 8);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(124, 23);
            this.labelControl2.TabIndex = 8;
            this.labelControl2.Text = "Select Meter No";
            // 
            // gcMouseDouble
            // 
            this.gcMouseDouble.DataSource = this.tblDoubleClickBindingSource;
            this.gcMouseDouble.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gcMouseDouble.Location = new System.Drawing.Point(5, 31);
            this.gcMouseDouble.MainView = this.gvMouseDouble;
            this.gcMouseDouble.Name = "gcMouseDouble";
            this.gcMouseDouble.Size = new System.Drawing.Size(311, 297);
            this.gcMouseDouble.TabIndex = 0;
            this.gcMouseDouble.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvMouseDouble});
            this.gcMouseDouble.Click += new System.EventHandler(this.gcMouseDouble_Click);
            // 
            // tblDoubleClickBindingSource
            // 
            this.tblDoubleClickBindingSource.DataMember = "tbl_DoubleClick";
            this.tblDoubleClickBindingSource.DataSource = this.dAL_DS_ElectricityReadings;
            // 
            // gvMouseDouble
            // 
            this.gvMouseDouble.ColumnPanelRowHeight = 46;
            this.gvMouseDouble.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colcem_location,
            this.colcem_meter_no});
            this.gvMouseDouble.GridControl = this.gcMouseDouble;
            this.gvMouseDouble.GroupRowHeight = 30;
            this.gvMouseDouble.Name = "gvMouseDouble";
            this.gvMouseDouble.OptionsFind.AlwaysVisible = true;
            this.gvMouseDouble.OptionsView.ShowGroupPanel = false;
            this.gvMouseDouble.OptionsView.ShowHorizontalLines = DevExpress.Utils.DefaultBoolean.True;
            this.gvMouseDouble.OptionsView.ShowIndicator = false;
            this.gvMouseDouble.RowHeight = 25;
            this.gvMouseDouble.DoubleClick += new System.EventHandler(this.gvMouseDouble_DoubleClick);
            // 
            // colcem_location
            // 
            this.colcem_location.AppearanceCell.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colcem_location.AppearanceCell.Options.UseFont = true;
            this.colcem_location.AppearanceCell.Options.UseTextOptions = true;
            this.colcem_location.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.colcem_location.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colcem_location.AppearanceHeader.Options.UseFont = true;
            this.colcem_location.AppearanceHeader.Options.UseTextOptions = true;
            this.colcem_location.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colcem_location.Caption = "Location";
            this.colcem_location.FieldName = "cem_location";
            this.colcem_location.Name = "colcem_location";
            this.colcem_location.OptionsColumn.AllowEdit = false;
            this.colcem_location.OptionsColumn.ReadOnly = true;
            this.colcem_location.Visible = true;
            this.colcem_location.VisibleIndex = 0;
            this.colcem_location.Width = 234;
            // 
            // colcem_meter_no
            // 
            this.colcem_meter_no.AppearanceCell.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colcem_meter_no.AppearanceCell.Options.UseFont = true;
            this.colcem_meter_no.AppearanceCell.Options.UseTextOptions = true;
            this.colcem_meter_no.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colcem_meter_no.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colcem_meter_no.AppearanceHeader.Options.UseFont = true;
            this.colcem_meter_no.AppearanceHeader.Options.UseTextOptions = true;
            this.colcem_meter_no.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colcem_meter_no.Caption = "Meter No";
            this.colcem_meter_no.FieldName = "cem_meter_no";
            this.colcem_meter_no.Name = "colcem_meter_no";
            this.colcem_meter_no.OptionsColumn.AllowEdit = false;
            this.colcem_meter_no.OptionsColumn.ReadOnly = true;
            this.colcem_meter_no.Visible = true;
            this.colcem_meter_no.VisibleIndex = 1;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.DodgerBlue;
            this.labelControl1.Appearance.Options.UseFont = true;
            this.labelControl1.Appearance.Options.UseForeColor = true;
            this.labelControl1.Location = new System.Drawing.Point(12, 107);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(106, 21);
            this.labelControl1.TabIndex = 7;
            this.labelControl1.Text = "Daily Readings";
            // 
            // Form1
            // 
            this.Appearance.Options.UseFont = true;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1174, 767);
            this.Controls.Add(this.pnlData);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.panelControl3);
            this.Controls.Add(this.gcView);
            this.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.IconOptions.ShowIcon = false;
            this.LookAndFeel.SkinName = "Metropolis";
            this.LookAndFeel.UseDefaultLookAndFeel = false;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CDL Electricity Meter Readings Entry Module";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tblreadingsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dAL_DS_ElectricityReadings)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTime.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLocation.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMeterNo.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCurrent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaximum.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblviewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).EndInit();
            this.panelControl3.ResumeLayout(false);
            this.panelControl3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txttest.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tdate1.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tdate1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlData)).EndInit();
            this.pnlData.ResumeLayout(false);
            this.pnlData.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcMouseDouble)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblDoubleClickBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvMouseDouble)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.BindingSource tblreadingsBindingSource;
        private DAL.DataSource.DAL_DS_ElectricityReadings dAL_DS_ElectricityReadings;
        private DevExpress.XtraEditors.LabelControl lblDate;
        private DevExpress.XtraEditors.LabelControl lblTime;
        private DevExpress.XtraEditors.TextEdit txtTime;
        private DevExpress.XtraEditors.TextEdit txtLocation;
        private DevExpress.XtraEditors.LabelControl lblMeterNo;
        private DevExpress.XtraEditors.TextEdit txtMeterNo;
        private DevExpress.XtraEditors.LabelControl lblKVA;
        private DevExpress.XtraEditors.TextEdit txtMaximum;
        private DevExpress.XtraEditors.LabelControl lblMaximum;
        private DevExpress.XtraEditors.LabelControl lblKWH;
        private DevExpress.XtraEditors.TextEdit txtCurrent;
        private DevExpress.XtraEditors.LabelControl lblCurrentRead;
        private DevExpress.XtraGrid.GridControl gcView;
        private DevExpress.XtraGrid.Views.Grid.GridView gvView;
        private System.Windows.Forms.BindingSource tblviewBindingSource;
        private DevExpress.XtraGrid.Columns.GridColumn colcev_date;
        private DevExpress.XtraGrid.Columns.GridColumn colcev_time;
        private DevExpress.XtraGrid.Columns.GridColumn colcev_curr_reading;
        private DevExpress.XtraGrid.Columns.GridColumn colcev_pre_reading;
        private DevExpress.XtraGrid.Columns.GridColumn colcev_cur_comsumption;
        private DevExpress.XtraEditors.PanelControl panelControl3;
        private DevExpress.XtraEditors.SimpleButton btn_new;
        private DevExpress.XtraEditors.SimpleButton btn_Save;
        private DevExpress.XtraEditors.DateEdit tdate1;
        private DevExpress.XtraEditors.PanelControl pnlData;
        private DevExpress.XtraGrid.GridControl gcMouseDouble;
        private DevExpress.XtraGrid.Views.Grid.GridView gvMouseDouble;
        private System.Windows.Forms.BindingSource tblDoubleClickBindingSource;
        private DevExpress.XtraGrid.Columns.GridColumn colcem_location;
        private DevExpress.XtraGrid.Columns.GridColumn colcem_meter_no;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.SimpleButton btn_Load;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.TextEdit txttest;
        private DevExpress.XtraGrid.Columns.GridColumn cev_meter_no;
        private DevExpress.XtraEditors.TextEdit textEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn cev_maximum_demand;
    }
}

