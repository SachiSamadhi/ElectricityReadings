﻿using DevExpress.XtraEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace ElectricityReadings
{
    public partial class Form1 : DevExpress.XtraEditors.XtraForm
    {
        BLL.BLL_CS_ElectricityReadings BLL_CS_ElectricityReadings = new BLL.BLL_CS_ElectricityReadings();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;

            tdate1.Text = now.ToString("yyyy-MM-dd");
            txtTime.Text = now.ToString("HH:mm");

            string cerDate = tdate1.Text;


            gcView.DataSource = BLL_CS_ElectricityReadings.GetReadingByDate(cerDate);





        }

        private void gvView_RowClick(object sender, DevExpress.XtraGrid.Views.Grid.RowClickEventArgs e)
        {
            if (e.RowHandle >= 0)
            {
                DataRow row = gvView.GetDataRow(e.RowHandle);
                if (row != null)
                {
                    txtMeterNo.Text = row["cer_meter_no"].ToString();


                    if (DateTime.TryParse(row["cer_date"].ToString(), out DateTime cerDate))
                        tdate1.Text = cerDate.ToString("yyyy-MM-dd");

                    txtTime.Text = row["cer_time"].ToString();
                    txtMaximum.Text = row["cer_maximum_demand"].ToString();
                    txtCurrent.Text = row["cer_current_reading"].ToString();
                    txtMeterNo.Text = row["cev_meter_no"].ToString();
                    txtLocation.Text = row["location"].ToString();
                }
            }


        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void lblKVA_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void lblKVA_Click_1(object sender, EventArgs e)
        {

        }

        private void gcView_Click(object sender, EventArgs e)
        {

        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            string cerDate = tdate1.Text.Trim();
            string cerTime = txtTime.Text.Trim();
            string meterNo = txtMeterNo.Text.Trim();
            string cerMaximumDemand = txtMaximum.Text.Trim();
            string cerCurrentReading = txtCurrent.Text.Trim();
            string update = txttest.Text.Trim();


            if (string.IsNullOrEmpty(meterNo))
            {
                XtraMessageBox.Show(this.LookAndFeel, "Meter No cannot be blank", "CDL Electricity Meter Readings", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }


            if (string.IsNullOrEmpty(cerDate))
            {
                XtraMessageBox.Show(this.LookAndFeel, "Date cannot be blank", "CDL Electricity Meter Readings", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }


            if (string.IsNullOrEmpty(cerTime))
            {
                XtraMessageBox.Show(this.LookAndFeel, "Time cannot be blank", "CDL Electricity Meter Readings", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }


            if (!double.TryParse(cerMaximumDemand, out double cerMaximumDemandVal))
            {
                XtraMessageBox.Show(this.LookAndFeel, "Maximum demand must be a numeric value", "CDL Electricity Meter Readings", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            if (cerMaximumDemandVal <= 0)
            {
                XtraMessageBox.Show(this.LookAndFeel, "Maximum demand must be greater than zero", "CDL Electricity Meter Readings", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }


            if (!double.TryParse(cerCurrentReading, out double cerCurrentReadingVal))
            {
                XtraMessageBox.Show(this.LookAndFeel, "Current reading must be a numeric value", "CDL Electricity Meter Readings", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            if (cerCurrentReadingVal <= 0)
            {
                XtraMessageBox.Show(this.LookAndFeel, "Current reading must be greater than zero", "CDL Electricity Meter Readings", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }


            if (string.IsNullOrEmpty(update))
            {
                int mem_count = BLL_CS_ElectricityReadings.CheckDuplicate(meterNo, cerDate);
                if (mem_count > 0)
                {
                    XtraMessageBox.Show(this.LookAndFeel, "Duplicate Record", "CDL Electricity Meter Readings", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }


            bool saveElectricity = BLL_CS_ElectricityReadings.SaveElectricityReading(
                cerDate, cerTime, meterNo, cerMaximumDemand, cerCurrentReading, update);

            if (saveElectricity)
            {
                XtraMessageBox.Show(this.LookAndFeel, string.IsNullOrEmpty(update) ?
                    "Electricity reading saved successfully" : "Electricity reading updated successfully",
                    "CDL Electricity Meter Readings", MessageBoxButtons.OK, MessageBoxIcon.Information);


                gcView.DataSource = BLL_CS_ElectricityReadings.LoadDailyView(meterNo, cerDate);


                var view = gcView.FocusedView as DevExpress.XtraGrid.Views.Grid.GridView;
                if (view != null && view.RowCount > 0)
                {
                    view.FocusedRowHandle = view.RowCount - 1;

                    txtMeterNo.Text = view.GetFocusedRowCellValue("cev_meter_no")?.ToString() ?? "";
                    txtMaximum.Text = view.GetFocusedRowCellValue("cev_maximum_demand")?.ToString() ?? "";
                    txtCurrent.Text = view.GetFocusedRowCellValue("cev_curr_reading")?.ToString() ?? "";
                    txtLocation.Text = view.GetFocusedRowCellValue("location")?.ToString() ?? "";

                    object timeVal = view.GetFocusedRowCellValue("cev_time");
                    if (timeVal != null && timeVal != DBNull.Value)
                        txtTime.Text = Convert.ToDateTime(timeVal).ToString("HH:mm");
                    else
                        txtTime.Text = DateTime.Now.ToString("HH:mm");

                    txttest.Text = "1";
                }
            }
            else
            {
                XtraMessageBox.Show(this.LookAndFeel, "Error while saving electricity reading",
                    "CDL Electricity Meter Readings", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tdate1_EditValueChanged(object sender, EventArgs e)
        {
            string meterNo = txtMeterNo.Text.Trim();
            string cerDate = tdate1.Text.Trim();


            if (!string.IsNullOrEmpty(cerDate))
            {
                gcView.DataSource = BLL_CS_ElectricityReadings.GetElecReadingbyDate(cerDate);
            }
            if (string.IsNullOrEmpty(meterNo))
            {
                //XtraMessageBox.Show(this.LookAndFeel, "Please enter Meter No.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //int mem_count = BLL_CS_ElectricityReadings.CheckDuplicate(meterNo, cerDate);
            //if (mem_count > 0)
            //{
            //    XtraMessageBox.Show(this.LookAndFeel, "Duplicate Record", "CDL Electricity Meter Readings", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //}

            gcView.DataSource = BLL_CS_ElectricityReadings.GetElecReadingbyDate(cerDate);
            gcView.RefreshDataSource();

            if (string.IsNullOrEmpty(txttest.Text))
            {
                txtTime.Text = DateTime.Now.ToString("HH:mm");
            }
            //bool invalidDate = BLL_CS_ElectricityReadings.IsInvalidNextDate(meterNo, selectedDate, out expectedDate);

            //if (invalidDate)
            //{
            //    XtraMessageBox.Show(this.LookAndFeel,
            //        "Incorrect date - Date should be " + expectedDate.ToString("yyyy-MM-dd"),
            //        "CDL Electricity Meter Readings",
            //        MessageBoxButtons.OK,
            //        MessageBoxIcon.Warning);

            //    tdate1.EditValue = expectedDate; 
            //    tdate1.Focus();
            //    return;   
            ////}
            //if(mem_count > 0)
            //{
            //    XtraMessageBox.Show(this.LookAndFeel, "Duplicate Record ", "CDL Electricity Meter Readings", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //    return;

            //    //tdate1.EditValue = null;
            //    //tdate1.Focus();
            //}


        }
        private void ShowListOfValues(string meterNo)
        {
            MessageBox.Show("Open List of Values for meter " + meterNo);

        }
        private void LoadReadingView()
        {
            string meterNo = txtMeterNo.Text;
            string cerDate = tdate1.Text;

            //DateTime dtValue = Convert.ToDateTime(cerDate);
            //string cdate = dtValue.ToString("yyyy-MM");

            gcView.DataSource = BLL_CS_ElectricityReadings.LoadDailyView(meterNo, cerDate);



        }

        private void txtMeterNo_EditValueChanged_1(object sender, EventArgs e)
        {
            
            string meterNo = txtMeterNo.Text.Trim();
            string cerDate = tdate1.Text.Trim();

            //if (string.IsNullOrEmpty(meterNo))
            //{
            //    XtraMessageBox.Show("Please enter Meter No first.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //    return;
            //}


            //int mem_count = BLL_CS_ElectricityReadings.CheckDuplicate(meterNo, cerDate);
            //if (mem_count > 0)
            //{
            //    XtraMessageBox.Show(this.LookAndFeel, "Duplicate Record", "CDL Electricity Meter Readings", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //}

            //DataTable dt = BLL_CS_ElectricityReadings.LoadDailyView(meterNo, cerDate);
            //gcView.DataSource = dt;
            //gcView.RefreshDataSource();
            //tdate1_EditValueChanged( sender,  e);


        }

        private void txtMeterNo_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            gcMouseDouble.DataSource = BLL_CS_ElectricityReadings.GetMeters();

        }

        private void txtMeterNo_DoubleClick(object sender, EventArgs e)
        {
            pnlData.Visible = true;
            gcMouseDouble.DataSource = BLL_CS_ElectricityReadings.GetMeters();

        }

        private void gvMouseDouble_DoubleClick(object sender, EventArgs e)
        {


            txtMeterNo.Text = gvMouseDouble.GetFocusedRowCellValue("cem_meter_no").ToString();
            txtLocation.Text = gvMouseDouble.GetFocusedRowCellValue("cem_location").ToString();

            pnlData.Visible = false;

        }

        private void gcMouseDouble_Click(object sender, EventArgs e)
        {

        }
        private void btn_Save_MouseClick(object sender, MouseEventArgs e)
        {
            //BLL_CS_ElectricityReadings.LoadDailyView();
        }
        private void txtMaximum_EditValueChanged(object sender, EventArgs e)
        {
           
            //tdate1_EditValueChanged(sender, e);
            //tdate1.EditValueChanged -= tdate1_EditValueChanged;
            //txtMaximum.Text = "";
            //tdate1.EditValueChanged += tdate1_EditValueChanged;
        }
        private void pnlData_Paint(object sender, PaintEventArgs e)
        {

        }
        private void txtCurrent_EditValueChanged(object sender, EventArgs e)
        {

        }
        private void ClearForm()
        {
            txtMeterNo.Text = "";
            txtLocation.Text = "";
            txtMaximum.Text = "";
            txtCurrent.Text = "";
            txtTime.Text = DateTime.Now.ToString("HH:mm");
            tdate1.Text = DateTime.Now.ToString("yyyy-MM-dd");

        }
        private void btn_new_Click(object sender, EventArgs e)
        {
            txttest.Text = "";
            ClearForm();

            gcView.DataSource = null;
            txtMeterNo.Focus();
            txtTime.Text = DateTime.Now.ToString("HH:mm");
            pnlData.Visible = false;

        }
        private void simpleButton1_Click(object sender, EventArgs e)
        {
            string meterNo = txtMeterNo.Text.Trim();
            //if (string.IsNullOrEmpty(meterNo))
            //{
            //    txtMeterNo.Focus();
            //    XtraMessageBox.Show(this.LookAndFeel, "Meter No cannot be blank", "CDL Electricity Meter Readings", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            //    return;

            //}

            if (string.IsNullOrEmpty(tdate1.Text))
            {
                tdate1.Focus();
                return;
            }

            string cerDate = tdate1.Text;


            DataTable dt = BLL_CS_ElectricityReadings.LoadDailyView(meterNo, cerDate);

            gcView.DataSource = dt;
            gcView.RefreshDataSource();


            var view = gcView.FocusedView as DevExpress.XtraGrid.Views.Grid.GridView;
            if (view != null && view.RowCount > 0)
            {
                view.FocusedRowHandle = 0;

                txtMeterNo.Text = view.GetFocusedRowCellValue("cev_meter_no")?.ToString() ?? "";
                txtMaximum.Text = view.GetFocusedRowCellValue("cev_maximum_demand")?.ToString() ?? "";
                txtCurrent.Text = view.GetFocusedRowCellValue("cev_curr_reading")?.ToString() ?? "";
                txtLocation.Text = view.GetFocusedRowCellValue("location")?.ToString() ?? "";

                object timeVal = view.GetFocusedRowCellValue("cev_time");
                if (timeVal != null && timeVal != DBNull.Value)
                    txtTime.Text = Convert.ToDateTime(timeVal).ToString("HH:mm");
                else
                    txtTime.Text = DateTime.Now.ToString("HH:mm");

                txttest.Text = "1";
            }





        }

        private void txtLocation_EditValueChanged(object sender, EventArgs e)
        {
            
            string meterNo = txtMeterNo.Text.Trim();
            string cerDate = tdate1.Text.Trim();

            //if (string.IsNullOrEmpty(meterNo))
            //{
            //    XtraMessageBox.Show("Please enter Meter No first.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //    return;
            //}


            //int mem_count = BLL_CS_ElectricityReadings.CheckDuplicate(meterNo, cerDate);
            //if (mem_count > 0)
            //{
            //    XtraMessageBox.Show(this.LookAndFeel, "Duplicate Record", "CDL Electricity Meter Readings", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //}

            DataTable dt = BLL_CS_ElectricityReadings.LoadDailyView(meterNo, cerDate);
            gcView.DataSource = dt;
            gcView.RefreshDataSource();
            tdate1_EditValueChanged(sender, e);

        }

        private void labelControl3_Click(object sender, EventArgs e)
        {
            pnlData.Visible = false;
        }

        private void gcView_RowClick(object sender, EventArgs e)
        {

        }

        private void gvView_RowCellClick(object sender, DevExpress.XtraGrid.Views.Grid.RowCellClickEventArgs e)
        {

            if (e.RowHandle < 0) return;

            txttest.Text = "1";

            var view = sender as DevExpress.XtraGrid.Views.Grid.GridView;

            tdate1.EditValueChanged -= tdate1_EditValueChanged;
            txtLocation.EditValueChanged -= txtLocation_EditValueChanged;

            tdate1.Text = view.GetRowCellValue(e.RowHandle, "cev_date")?.ToString() ?? "";
            txtCurrent.Text = view.GetRowCellValue(e.RowHandle, "cev_curr_reading")?.ToString() ?? "";
            txtMeterNo.Text = view.GetRowCellValue(e.RowHandle, "cev_meter_no")?.ToString() ?? "";
            txtMaximum.Text = view.GetRowCellValue(e.RowHandle, "cev_maximum_demand")?.ToString() ?? "";
            txtLocation.Text = view.GetRowCellValue(e.RowHandle, "location")?.ToString() ?? "";

            object timeVal = view.GetRowCellValue(e.RowHandle, "cev_time");
            if (timeVal != null && timeVal != DBNull.Value)
                txtTime.Text = Convert.ToDateTime(timeVal).ToString("HH:mm");

            tdate1.EditValueChanged += tdate1_EditValueChanged;
            txtLocation.EditValueChanged += txtLocation_EditValueChanged;

        }

        private void txtTime_EditValueChanged(object sender, EventArgs e)
        {
           
        }

        private void tdate1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void gvView_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            //var view = gcView.FocusedView as DevExpress.XtraGrid.Views.Grid.GridView;
            //if (view == null) return;


            //txtTime.Text = view.GetFocusedRowCellValue("cev_time") != null ?
            //               Convert.ToDateTime(view.GetFocusedRowCellValue("cev_time")).ToString("HH:mm") : "";


            //txtMeterNo.Text = view.GetFocusedRowCellValue("cev_meter_no")?.ToString() ?? "";


            //txtMaximum.Text = view.GetFocusedRowCellValue("cev_maximum_demand")?.ToString() ?? "";


            //txtCurrent.Text = view.GetFocusedRowCellValue("cev_curr_reading")?.ToString() ?? "";




            //txtLocation.Text = view.GetFocusedRowCellValue("location")?.ToString() ?? "";

        }

        private void txtMaximum_TextChanged(object sender, EventArgs e)
        {
            //string text = txtMaximum.Text.Replace(",", "");

            //Check if text is a valid number
            //if (long.TryParse(text, out long value))
            //{
            //    Format with commas
            //    txtMaximum.Text = value.ToString("N0");

            //    Keep cursor at the end
            //    txtMaximum.SelectionStart = txtMaximum.Text.Length;
            //}
            //else
            //{
            //Optional: clear if invalid input
            //    txtMaximum.Text = "";
            //}
        }

        private void txtMaximum_Leave(object sender, EventArgs e)
        {
            string text = txtMaximum.Text.Replace(",", "").Trim();


            if (long.TryParse(text, out long value))
            {

                txtMaximum.Text = value.ToString("N0");
            }

        }

        private void panelControl3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void gcView_Click_1(object sender, EventArgs e)
        {

        }

        private void lblMaximum_Click(object sender, EventArgs e)
        {

        }
    }
}